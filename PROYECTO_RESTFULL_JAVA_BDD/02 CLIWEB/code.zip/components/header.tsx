'use client'

interface HeaderProps {
  protocol: 'REST' | 'SOAP'
  onProtocolChange: (protocol: 'REST' | 'SOAP') => void
}

export default function Header({ protocol, onProtocolChange }: HeaderProps) {
  return (
    <header 
      className="text-white px-5 py-4 border-b-2"
      style={{ 
        backgroundColor: 'var(--bg-header)',
        borderBottomColor: 'var(--primary-dark)'
      }}
    >
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <span className="text-3xl">🏛️</span>
          <h1 className="text-2xl font-bold">ESPE - Comercializadora Electrodomésticos</h1>
        </div>

        <div className="flex items-center gap-4">
          <span className="font-medium">Protocolo:</span>
          <div 
            className="flex gap-2 px-2 py-1 rounded"
            style={{ backgroundColor: 'var(--primary-dark)' }}
          >
            <button
              onClick={() => onProtocolChange('REST')}
              className="px-4 py-1 rounded font-medium transition"
              style={{
                backgroundColor: protocol === 'REST' ? 'white' : 'transparent',
                color: protocol === 'REST' ? 'var(--primary)' : 'white'
              }}
            >
              REST
            </button>
            <button
              onClick={() => onProtocolChange('SOAP')}
              className="px-4 py-1 rounded font-medium transition"
              style={{
                backgroundColor: protocol === 'SOAP' ? 'white' : 'transparent',
                color: protocol === 'SOAP' ? 'var(--secondary)' : 'white'
              }}
            >
              SOAP
            </button>
          </div>
        </div>
      </div>
    </header>
  )
}
